 let nome = String(prompt('Digite o nome do personagem principal: '));
var inicioHistoria =   `<img id="acordando" src="imagens/roboacordando.jpeg" alt="Imagem acordando"><p>“Alarme de aviso tocado”<br>${nome} que é um robô, acorda sozinho em um lugar desconhecido, destruído como se tivesse acontecido uma guerra? um desastre? o que aconteceu neste cenário?<br> Quando de repente no seu sistema apareceu que estava com pouca bateria.<br><button onclick='carregarConteudo(continuar)'>Escolher uma nova aventura</button><br> <button onclick='carregarConteudo(fim)'>Escolher nada</button></p>`;

var continuar = `<img src="imagens/aventura.jpeg" alt="Imagem aventura"><p>“Felicitações por entrar nesse novo sistema, vamos começar nossa história, nosso robô ${nome} que iremos conhecer está totalmente perdido em lugares desconhecidos e a fim de acabar com essa dúvida terrível.<br><button onclick='carregarConteudo(conhecer)'>Ver o menu da personagem</button><br> <button onclick='carregarConteudo(acao)'>Pular isso e ir direto para a ação</button></p>`;

var acao = `<img id="acordando" src="imagens/roboacordando.jpeg" alt="Imagem acordando"><p>Como você pulou o menu, não percebeu uma falha crítica por um cabo solto, seu ${nome} falhou e morreu.</p><button onclick='carregarConteudo(inicioHistoria)'>Reiniciar</button>`;

var conhecer = `<img src="imagens/aventura.jpeg" alt="Imagem aventura"><p>Clique aqui para saber mais, confia <br><button onclick='carregarConteudo(saber)'>Saber mais</button></p>`;

var saber = `<img src="imagens/menu.jpeg" alt="Imagem menu"><p> O nosso robô veio de uma civilização extremamente avançada, ele checa todo o seu sistema para saber se está bem a cada 2 segundos, tem inteligência artificial própria e seus objetivos são definidos e ele sempre cumpre sua missão com 100% de acertividade, interage com as pessoas, expressa emoções e gosta de animais <br> <button onclick='carregarConteudo(segmento)'>Continuar</button></p>`;

var segmento = `<img src="imagens/loja.jpeg" alt="Imagem loja"><p>Ao ver o menu, nosso robô percebe uma falha causada por um cabo solto, arrumando-no e garantindo que seu destino continue, no mesmo momento ele percebe uma mensagem sobre sua bateria estar em nível baixo, ele repara em uma loja estilhaçada e entra a procura de energia, vendo uma tomada.<br> <button onclick='carregarConteudo(carregar)'>Plugar na tomada</button><br> <button onclick='carregarConteudo(explorar)'>Explorar a loja</button></p>`;

var carregar = `<img src="imagens/loja.jpeg" alt="Imagem loja"><p>Não tem energia.<br> <button onclick='carregarConteudo(explorar)'>Explorar a loja</button></p>`;

var explorar = `<img src="imagens/loja.jpeg" alt="Imagem loja"><p>Ao explorar a loja ele se depara com armário de vidro, e dentro desse armário tem uma bateria onde pode carregar
um pouco suas forças.<br><button onclick='carregarConteudo(bateria)'>Abrir armário</button> <br> <button
onclick='carregarConteudo(bateria)'>Quebrar o vidro do armário</button></p>`;
var bateria = `<img src="imagens/loja.jpeg" alt="Imagem loja"><p>Ao pegar bateria ele encaixa em seu suporte para recarregar suas energias, depois disso continuou explorando e não achou, mas nada.<br><button onclick='carregarConteudo(continuar0)'>Continuar</button></p>`;

var continuar0 = `<img src="imagens/andando.jpeg" alt="Imagem andando"><p>Andando pelas ruas destruídas encontra um base militar, ele se aproxima com cuidado, quando entra ele vê um robozinho que está quebrado
- Por favor me ajude falou o  robozinho?<br><button onclick='carregarConteudo(ajuda)'>Sim posso te ajudar irei compartilhar um pouco da minha energia!!</button><button onclick='carregarConteudo(naoAjuda)'>Não posso te ajudar pois estou à procura de uma nova bateria se eu parar posso desativar adeus.</button></p>`

var ajuda = `<img src="https://i.ytimg.com/vi/Zhh6klqQfTI/maxresdefault.jpg" alt="Robos conversando"><p>Obrigado amigo<br> – Disse o robozinho
Tudo bem, fico feliz em te ajudar<br> – disse nosso robô <br>
Com o reparo do robozinho a bateria volta a apitar com carga baixa e o uso de sua ferramenta de reparo queimou uma de suas placas, como ele não estava forte o suficiente para restaurar sua energia, preocupado ${nome} pergunta:
Você tem algum kit de reparo e fonte de energia onde eu possa carregar?<br>
Não sei, minha memória está corrompida, apenas acordei quebrado, agradeço muito por ter me ajudado, mas podemos procurar juntos.<br><button onclick='carregarConteudo(juntoSozinho)'>Procurar Junto</button><br> <button onclick='carregarConteudo(juntoSozinho)'>Procurar Sozinho</button></p>`

var naoAjuda = ` <img src="imagens/naoajudarobo.jpeg" alt="Imagem loja"><p>Ao deixar robozinho de lado ele segue em frente até encontrar 10 máquinas de guerras que operam automaticamente, ele tenta procurar uma forma de hackear porém elas só podem ser operadas a partir de um sistema a distância o qual ele não tem, ao avistar o ${nome} as máquinas o destroem<br><button onclick='carregarConteudo(inicioHistoria)'>Voce morreu, Retorne</button></p>`

var juntoSozinho = `<img src="imagens/procurar.jpeg" alt="Imagem loja"><p>A procura infelizmente não traz o melhor resultado, mas por sorte o nosso robô achou um kit pequeno de reparo que poderia prolongar mais um pouco sua vida útil, ele reparou a placa queimada e conseguiu estender um pouca mais a bateria com um pote de energia reserva que obteve no kit.
Ao andarem por um bom tempo, os nossos 2 robôs avistam máquinas de guerras a quais aparenta perseguir algo, ao usar o zoom que eles têm instalados descobrem que a pessoa em perigo é uma menina, os robôs conversam entre si<br><button onclick='carregarConteudo(salva)'>Podemos salvar a criança, aquele tipo de máquinas é operadas a partir de um sistema automatizado, posso entrar na frequência e desativá-las – falam entre si os robôs</button> <br> <button onclick='carregarConteudo(abandona)'> Podemos simplesmente abandonar a humana e seguirmos adiante – concordam entre si os robôs</button>
</p>`

var abandona = `<img src="imagens/naoajudarobo.jpeg" alt="Imagem cidade"><p>Ao deixar a morte triste da humana ocorrer, os robôs seguem sua viagem adiante, conforme foram andando encontraram a entrada de uma cidade que apesar das ruínas em que estavam era em melhor que aquele deserto devastado anterior onde estavam, os robôs são parados em um sistema de segurança contra máquinas de guerra instalado, por não possuírem um humano com eles, são declarados como hostis e são destruído<br><button onclick='carregarConteudo(inicioHistoria)'>Voce morreu, Reiniciar</button></p>`

var salva = ` <img src="imagens/menina.jpeg" alt="Imagem cidade">
<p>Após concordarem em salvar a criança, os robôs bolam um plano, onde o robozinho irá entrar na frequência das
    máquinas de guerra e nosso robô irá atraí-las, com o plano em prática ele ataca uma barra de ferro nas
    máquinas, em seguida elas correm atrás dele E ENTÃO JÁ CONSEGUIU? ATÉ PORQUE EU NÃO QUERO SER
    DESTROÇADO AQUI NÃO!<br>
    Calma, estou decodificando o sinal Correndo como um cachorro corre do banho nosso robô 
    consegue cumprir bem o papel, com a frequência decifradas, todas máquinas são desativadas, e então vão até a
    criança<br>
    -Obrigada por me salvarem, qual é o nome de vocês? Nome? Não consigo recordar meu modelo, estou com
    falha no sistema<br>
    – disse o robozinho Eu também não consigo me recordar do meu modelo<br> – disse nosso robô  Não
    quero saber o modelo, mas sim o nome de vocês! Mas desde quando máquinas têm nomes?
    – rindo nosso robô <br> Pois
    bem, como um gesto de gratidão ajudarei vocês com isso, darei um nome a vocês, como você é alto e forte te
    chamarei de Megatron, e você que é pequenino como eu chamarei de átomo! Átomo? Tá de sacanagem? Átomo?<br>
    Porque
    ele é o mega?<br> Eu quero ser então o super ou Max<br>
    – muito bravo reclamou átomo<br> Calma lá, é só uma criança Você
    fala isso porque teve um nome maneiro, não de uma partícula minúscula, você é mega e eu átomo Aos risos a menina
    diz<br>
    – A Propósito meu nome é Luna, eu vi que vocês têm algumas coisas para reparar, conheço um professor muito
    bom para ajudar vocês </p><button onclick='carregarConteudo(discutir)'>Discutir</button> <br> <button onclick='carregarConteudo(professor)'>Ir até o professor</button>`

var discutir = `<img src="imagens/crianca.jpeg" alt="Imagem criança"><p>Sério que em um cenário de guerra você quer ver briga por nome?<br><button onclick='carregarConteudo(salva)'>Retornar</button><br></p>`


var professor = `<img src="imagens/professor.jpeg" alt="Imagem professor"><p>A caminho do professor falado por Luna, nossa equipe tem um problema, átomo não para de reclamar do nome dado pela garota, porém eles chegam a uma cidade nova onde apesar de estar aos pedaços é melhor que o local onde estavam com as máquinas de guerra, em seguida são parados em uma barreira ante máquinas de guerra, Luna aparece e fala
Calma lá, estes robôs são meus amigos, são o Megatron e Átomo, estou levando-os ao professor, precisam de reparos!
<br>O sistema reconhece a garota e libera a entrada das máquinas. Ao entrarem na cidade percebem muitas coisas que não tinham visto antes, então eles se entre olham e falam<br><button onclick='carregarConteudo(explorar0)'>Explorar Cidade</button><br> <button onclick='carregarConteudo(professor0)'>Vamos direto ao professor, depois damos uma olhada na cidade.</button></p>`

var explorar0 = `<img src="imagens/cidade0.jpeg" alt="Imagem professor"><p>Os robôs estão quebrados, a ponto de serem desativados e você ainda quer explorar a cidade?<br><button onclick='carregarConteudo(professor)'>Retornar</button></p>`

var professor0 = `<img src="imagens/professor.jpeg" alt="Imagem professor"><p>Chegando à base do professor a garota grita ele com todas suas forças, ele aparece assustado e olha aquelas máquinas e questiona
Conheço vocês de algum lugar?
Não temos como saber, nossos  disco de memória foi afetado, não sabemos nada do que aconteceu, únicas memórias que temos salvas são as de hoje
Aliás, gente esse é o Professor Gabriel, ele é o melhor quando se trata sobre máquinas!
MIIIIIIIAAUUU ~ Luna você voltou!<br> – gritou o gato
Rei é você <br>- Luna abraçava o bichano com muito carinho
Quanto tempo, o que aconteceu com você garota?<br>
Enquanto sai em uma missão de exploração por conta própria fui cercada por máquinas de guerra<br>
Não me diga! E como você conseguiu escapar?<br>
Megatron e Átomo me salvaram, graças a eles estou aqui!<br>
Miau, quem são esses? Luna aponta ao robôs<br> 
Ele vieram aqui para o Prof. Arrumá Los<br><button onclick='carregarConteudo(continuar01)'>Continuar</button></p>`

var continuar01 = `<img src="imagens/robo.jpeg" alt="Imagem cidade"><p>Com o conserto dos robôs, o professor fala:<br>
Vocês me lembram muito uns projetos em qual trabalhei, se quiser posso dar uma olhada no sistema de vocês com a máquina e reparar os erros de sistema.<br>
Mas já não estamos arrumados?<br> Disse Átomo<br> 
Acredito que não, ainda tenho  o problema da bateria.<br>
Olha quanto a sua bateria, ela está 100% o seu problema é um erro de sistema, em alguns dias posso consertar
<br>Então quer dizer que a todo momento estava achando que iria desligar, mas não passa de um erro de sistema?<br>
Miau,  o Prof disse é porque é isto mesmo 
(Explosões no fundo) uma pessoa passa gritando alertado a todos:
As máquinas estão aqui, precisamos de todos que possam ajudar para defender nossa cidade!

E então você quer que eu te concerte? ou Prefere ir nos ajudar agora nesta urgência<br><button onclick='carregarConteudo(concerta)'>Conserta agora</button><br><button onclick='carregarConteudo(ajuda0)'>Ajudar a sua nova cidade</button></p>`

var concerta = `<img src="imagens/robo.jpeg" alt="Imagem cidade"><p>Não deu tempo de consertar o nosso robô , pois no 2 dia todos da cidade foram destruídos<br><button onclick='carregarConteudo(inicioHistoria)'>Voce morreu, reiniciar</button></p>`

var ajuda0 = `<img src="imagens/robo.jpeg" alt="Imagem cidade"><p>Os robôs decidem que o seu concerto pode ser adiado, o mais importante no momento é proteger a todos da sua nova
terra, diferente daquela em que acordou que estava aos pedaços, todos vão na direção do centro da cidade para
receber ordens e conseguir proteger ela.
TODOS OS QUE PUDEREM AJUDAR PROTEGER NOSSO LAR DE UM PASSO À FRENTE! - Gritou a Sargento
Sargento nós podemos ajudar! Gritou o professor<br>
Como pode nos ajudar ?<br>
Sargento tem dois androids que conseguiram ajudar a Luna desativando as máquinas.<br>
É verdade isso? Impressionada perguntou a Sargento<br>
Sim, o átomo consegue hackear o sistema deles, eu posso servir de isca<br>
Se isso realmente funcionar podemos salvar a nossa cidade e pode prosperar de novo<br>
Sim sargento, eu consigo tranquilamente arrancar alguns fios e placas com as minhas garras, miau<br>
Ooow rei, você é tão fofinho quando fica bravo - disse a sargento<br>
Essa fofura aqui é fatal garota<br>
Luna rindo muito completa:<br>
Ser fofinho é uma arma para poucos, né?<br>
Depois de muitas risadas, eles focam no plano e o colocam em ação, Megatron com sua força e velocidade consegue
atrair as máquinas, enquanto o rei de fato cumpre com o que fala, suas garras são tão fortes como aço e consegue
afetar algumas máquinas retirando fios e placas, enquanto isso átomo começa a decodificação das máquinas de
guerra para desativá las<br>
Meus Deus esse gato não é só fofura não - Espantada disse a sargento<br>
Isso não é nada, rei não é um gato comum, ele é meio android, achamos ele quase morto e abandonado, com a ajuda
do prof consegui salvar meu amigo, agora ele é um gatobô!<br>
Apesar de muita batalha e luta eles conseguem derrotar todas máquinas, o povo em êxtase gritando aos delírios
saudando os heróis fazem o convite<br>
Venha festejar conosco nobres heróis!<br>
Uma decisão difícil para eles, pois eles têm a necessidade agora de serem de fatos arrumados, pois com a guerra,
tudo que o professor tinha feito acabou sendo quebrado novamente!<br><br><button onclick='carregarConteudo(festejar)'>Escolher festejar</button><button onclick='carregarConteudo(arrumado)'>Escolher ser arrumado</button><br></p>`

var festejar = `<img id="acordando" src="imagens/festejar.jpeg" alt="Imagem acordando"><p> Você quebrou, agora não tem jeito virou sucata, sua placa mãe foi pro beleléu pelo superaquecimento causado pela batalha anterior<br><button onclick='carregarConteudo(inicioHistoria)'>Voce morreu, reiniciar</button></p>`

var arrumado = `<img id="acordando" src="imagens/fim.jpeg" alt="Imagem acordando"><p>Ao chegar na casa do professor, nossos robôs foi reparado, se tivesse esperado mais algumas horas suas placas mãe teriam virado torradas, em seguida eles passaram na máquina que o professor tinha dito antes, tiveram seus sistemas arrumados, então professor disse<br>
Fico feliz em saber que estão melhor, e de fato vocês foram de um projeto que trabalhei, porém suas memória não conseguir reparar, o disco foi afetado, tudo estava sendo salvo em um compartimento de backup, porém agora estão arrumados e seu disco principal será usado novamente, mas não conseguir recuperar as lembranças de vocês anteriormente.
Tudo bem professor, apenas de poder ter um novo lar e um novo nome já fico feliz - disse nosso robô <br> 
Isso mesmo, estou feliz de estar com vocês - completou Megatron<br>
Então significa que vocês vão ficar? - Entusiasmada disse Luna<br> - Me solta, apesar de ser um gatobô não sou resistente a abraçoss forte garota <br>- reclamou rei
os robôs se entre olharam e concordaram com a garota:<br>
Sim ficaremos aqui.<br><button onclick='carregarConteudo(inicioHistoria)'>fim</button></p>`


var fim = `<img src="imagens/cidade.jpeg" alt="Imagem do fim">fim.<br><button onclick='carregarConteudo(inicioHistoria)'>Voltar inicio</button>`

var elemento = document.getElementById("conteudo");
var imagem = document.querySelector('img')


elemento.style.font = "normal bold 20px Arial"

elemento.style.textAlign = "center"
elemento.style.flexDirection = "column"


function carregarConteudo(conteudo) {
    elemento.innerHTML = conteudo;
}


function mudarEstilos() {
    text.style.color = "green";
    text.style.backgroundColor = "#000";
}

function mudarEstilosWhite() {
    text.style.color = "black";
    text.style.backgroundColor = "#fff";
}

carregarConteudo(inicioHistoria)

// Desenvolvido por Camila e Breno 
